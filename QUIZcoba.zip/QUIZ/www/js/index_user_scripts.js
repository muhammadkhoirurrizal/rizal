/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Materi */
    
    
        /* button  Soal */
    
    
        /* button  Soal */
    
    
        /* button  #btnBack */
    
    
        /* button  Back */
    
    
        /* button  Back */
    
    
        /* button  Materi */
    
    
        /* button  Soal */
    
    
        /* button  Soal */
    $(document).on("click", ".uib_w_5", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_2"); 
    });
    
        /* button  #btnBack */
    
    
        /* button  #btnBack */
    $(document).on("click", "#btnBack", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_1"); 
    });
    
        /* button  Back */
    
    
        /* button  Back */
    $(document).on("click", ".uib_w_9", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_1"); 
    });
    
        /* button  Back */
    $(document).on("click", ".uib_w_7", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_1"); 
    });
    
        /* button  Materi */
    $(document).on("click", ".uib_w_4", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_3"); 
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
